import React from 'react'

function OtherScreen() {
  return (
    <div>OtherScreen</div>
  )
}

export default OtherScreen